from django.urls import path
from django.conf.urls import url, include
from rest_framework import routers
from . import views


router = routers.DefaultRouter()
router.register(r'', views.PictureView)

urlpatterns = [
	path('', views.index, name='index'),
    url(r'', include(router.urls)),
    url(r'^search/(?P<search_term>[\w:|-]+)/$', views.PictureView.find, name='picture_search'),
]
