from rest_framework import serializers
from .models import Picture
from .models import Tag


class PictureSerializer(serializers.ModelSerializer):

    class Meta:
        model = Picture
        fields = [
            'picture_id',
            'cropped_picture',
            'full_picture'
            'camera',
            'author',
        ]
