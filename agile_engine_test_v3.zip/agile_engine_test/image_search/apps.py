from django.apps import AppConfig


class ImageSearchConfig(AppConfig):
    name = 'image_search'

    def ready(self):
        from .ext_api import ExtApi
        try:
            ext_api = ExtApi()
        except Exception as e:
            pass
        else:
            ext_api.get_images()
        return True
