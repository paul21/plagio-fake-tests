from django.contrib import admin
from .models import Picture
from .models import Tag

admin.site.register(Picture)
admin.site.register(Tag)