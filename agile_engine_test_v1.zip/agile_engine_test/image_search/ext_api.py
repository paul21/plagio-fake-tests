import json
import requests
from django.conf import settings
from .serializers import PictureSerializer


class ExtApi:

    def __init__(self):

        self.api_key = getattr(settings, 'EXT_API_KEY', None)
        self.base_url = getattr(settings, 'EXT_API_BASE_URL', None)

        if not self.api_key or not self.base_url:
            raise Exception('Incorrect settings')

        self.token = None

        data = {
            'apiKey': self.api_key
        }
        response = requests.post(f'{self.base_url}/auth', json=data)
        if response.status_code == requests.codes.ok:
            response_dict = json.loads(response.text)
            if 'token' in response_dict:
                self.token = response_dict['token']

        if not self.token:
            return

        self.headers = {
            'Authorization': f'Bearer {self.token}'
        }

    def get_token(self):

        data = {
            'apiKey': self.api_key
        }
        response = requests.post(f'{self.base_url}/auth', json=data)
        if response.status_code == requests.codes.ok:
            response_dict = json.loads(response.text)
            if 'token' in response_dict:
                return response_dict['token']

    def get_images(self):

        images = self.get_page()
        for image in images:
            if 'id' not in image:
                continue
            self.get_image_info(image['id'])

    def get_image_info(self, image_id):

        response = requests.get(f'{self.base_url}/images/{image_id}', headers=self.headers)
        if response.status_code == requests.codes.ok:
            response_dict = json.loads(response.text)
            response_dict['picture_id'] = response_dict.pop('id')
            serializer = PictureSerializer(data=response_dict)
            if serializer.is_valid():
                serializer.save()

    def get_image_by_id(self, image_id):

        response = requests.get(f'{self.base_url}/images/{image_id}', headers=self.headers)
        if response.status_code == requests.codes.ok:
            response_dict = json.loads(response.text)
            response_dict['picture_id'] = response_dict.pop('id')
            serializer = PictureSerializer(data=response_dict)
            if serializer.is_valid():
                serializer.save()

    def get_page(self, page=1):

        response = requests.get(f'{self.base_url}/images?page={page}', headers=self.headers)
        if response.status_code == requests.codes.ok:
            response_dict = json.loads(response.text)
            if 'pictures' in response_dict:
                return response_dict['pictures']
