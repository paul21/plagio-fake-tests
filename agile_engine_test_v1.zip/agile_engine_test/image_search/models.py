from django.db import models


class Picture(models.Model):
    picture_id = models.CharField(max_length=80)
    author = models.CharField(max_length=80)
    camera = models.CharField(max_length=80)
    cropped_picture = models.URLField(null=True)
    full_picture = models.URLField(null=True)
    created = models.DateTimeField(auto_now_add=True)


class Tag(models.Model):
    picture_id = models.ForeignKey(Picture, db_column='picture_id', on_delete=models.CASCADE)
    hashtag = models.CharField(max_length=200)

    class Meta:
        unique_together = ('picture_id', 'hashtag',)